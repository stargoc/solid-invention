from flask import Flask
from flask import request, render_template, redirect
from data.User import User
from page import Page
from user import RegisterForm
from login import LoginForm
from data import db_session
from flask_login import LoginManager, login_user

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
db_session.global_init("db/login.db")


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/calc', methods=['POST', 'GET'])
def form_sample():
    form = Page()
    if request.method == 'GET':
        return render_template('calc.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        c = request.form['mathematical action']
        string = f'{a} {c} {b}'
        answ = eval(string)
        return redirect(f'/answ/{answ}')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/main_page")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/main_page', methods=['GET', 'POST'])
def page_lol():
    form = Page()

    if request.method == "GET":
        return render_template('main_page.html', form=form)

    elif form.validate_on_submit():
        c = request.form['a']
        if request.method == 'POST':

            if c == 'Calc':
                return redirect('/calc')
            elif c == 'Fiz_calc_7':
                return redirect('/Fiz_calc_7')
            elif c == 'Geo_calc':
                return redirect('/Geo_Calc')
            elif c == 'Fiz_calc_8':
                return redirect('/Fiz_calc_8')
            elif c == 'Fiz_calc_9':
                return redirect('/Fiz_calc_9')


@app.route('/Fiz_calc_7', methods=['POST', 'GET'])
def calc():
    form = Page()
    if request.method == 'GET':
        return render_template('Fiz_calc_7.html', form=form)
    elif request.method == 'POST':
        c = request.form['physical formulas']
        if c == 'speed of uniform rectilinear motion':
            return redirect('/V')
        elif c == 'The formula for uniform speed of movement':
            return redirect('/V2')
        elif c == 'Density formula':
            return redirect("/ρ")
        elif c == 'Formula of moment of force':
            return redirect('/M')
        elif c == 'Pressure Formula':
            return redirect('/p')
        elif c == 'Hydrostatic pressure formula':
            return  redirect('/p2')
        elif c == 'Formula of Archimedean force':
            return redirect('/Fa')
        elif c == 'Work formula':
            return  redirect('/A')
        elif c == 'Power Formula':
            return redirect('/N')


@app.route('/answ/<answer>', methods=['POST', 'GET'])
def answer_main(answer):
    form = Page()
    if request.method == "GET":
     return render_template('Answer.html', answer=answer, form=form)
    elif form.validate_on_submit:
        return redirect("/main_page")



@app.route('/M', methods=['POST', 'GET'])
def answer0():
    form = Page()
    if request.method == "GET":
        return render_template('M.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/V2', methods=['POST', 'GET'])
def answer1():
    form = Page()
    if request.method == "GET":
        return render_template('V2.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        c = request.form['tretbe']
        answ = int(a) + (int(b) * int(c))
        return redirect(f'/answ/{answ}')


@app.route('/V', methods=['POST', 'GET'])
def answer2():
    form = Page()
    if request.method == "GET":
        return render_template('V.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')


@app.route('/ρ', methods=['POST', 'GET'])
def answer3():
    form = Page()
    if request.method == "GET":
        return render_template('ρ.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')


@app.route('/p', methods=['POST', 'GET'])
def answer4():
    form = Page()
    if request.method == "GET":
        return render_template('p.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')


@app.route('/p2', methods=['POST', 'GET'])
def answer5():
    form = Page()
    if request.method == "GET":
        return render_template('p2.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b) * 9.8
        return redirect(f'/answ/{answ}')


@app.route('/Fa', methods=['POST', 'GET'])
def answer6():
    form = Page()
    if request.method == "GET":
        return render_template('Fa.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b) * 9.8
        return redirect(f'/answ/{answ}')


@app.route('/A', methods=['POST', 'GET'])
def answer7():
    form = Page()
    if request.method == "GET":
        return render_template('A.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/N', methods=['POST', 'GET'])
def answer8():
    form = Page()
    if request.method == "GET":
        return render_template('N.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')


@app.route('/Geo_Calc', methods=['POST', 'GET'])
def Geo_calc():
    form = Page()
    if request.method == 'GET':
        return render_template('Geo_calc.html', form=form)
    elif request.method == 'POST':
        c = request.form['Geo formulas']
        if c == 'Pythagorean theorem':
            return redirect('/pif')
        elif c == 'Parallelogram area':
            return redirect('/S_of_Parallelogram')
        elif c == 'Rectangle area':
            return redirect("/S_of_Rectangle")
        elif c == 'square area':
            return redirect('/S_of_Square')
        elif c == 'Height of a right triangle':
            return redirect('/Height_of_a_right_triangle')
        elif c == 'Heron formula':
            return  redirect('/Heron formula')
        elif c == 'Circumference':
            return redirect('/Circumference')
        elif c == 'Perimeter of a rectangle':
            return  redirect('/per')
        elif c == 'Area of triangle':
            return redirect('/Area_of_triangle')


@app.route('/S_of_Parallelogram', methods=['POST', 'GET'])
def answer9():
    form = Page()
    if request.method == "GET":
        return render_template('S_of_Parallelogram.html', form=form)
    elif form.validate_on_submit():
        a = request.form['pervoe']
        h = request.form['vtoroe']
        answ = int(a) * int(h)
        return redirect(f'/answ/{answ}')


@app.route('/pif', methods=['POST', 'GET'])
def answer10():
    form = Page()
    if request.method == "GET":
        return render_template('pif.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = (int(a) ** 2) + (int(b) ** 2)
        real_answ = answ ** 0.5
        return redirect(f'/answ/{real_answ}')


@app.route('/S_of_Rectangle', methods=['POST', 'GET'])
def answer11():
    form = Page()
    if request.method == "GET":
        return render_template('S_of_Rectangle.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        h = request.form['vtoroe']
        answ = int(a) * int(h)
        return redirect(f'/answ/{answ}')


@app.route('/S_of_Square', methods=['POST', 'GET'])
def answer12():
    form = Page()
    if request.method == "GET":
        return render_template('S_of_Square.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        answ = int(a) ** 2
        return redirect(f'/answ/{answ}')


@app.route('/Height_of_a_right_triangle', methods=['POST', 'GET'])
def answer13():
    form = Page()
    if request.method == "GET":
        return render_template('Height_of_a_right_triangle.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = (int(a) * int(b))
        real_answ = answ ** 0.5
        return redirect(f'/answ/{real_answ}')


@app.route('/Circumference', methods=['POST', 'GET'])
def answer14():
    form = Page()
    if request.method == "GET":
        return render_template('Circumference.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        answ = int(a) * 3.14 * 2
        return redirect(f'/answ/{answ}')


@app.route('/Heron formula', methods=['POST', 'GET'])
def answer15():
    form = Page()
    if request.method == "GET":
        return render_template('Heron formula.html', form=form)
    elif form.validate_on_submit:
        p = request.form['pervoe']
        a = request.form['vtoroe']
        b = request.form['tretbe']
        c = request.form['chert']
        answ = (int(p) * (int(p) - int(a)) * (int(p) - int(b)) * (int(p) - int(c))) ** 0.5
        return redirect(f'/answ/{answ}')


@app.route('/per', methods=['POST', 'GET'])
def answer16():
    form = Page()
    if request.method == "GET":
        return render_template('per.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = 2 * (int(a) + int(b))
        return redirect(f'/answ/{answ}')


@app.route('/Area_of_triangle', methods=['POST', 'GET'])
def answer17():
    form = Page()
    if request.method == "GET":
        return render_template('Area_of_triangle.html', form=form)
    elif form.validate_on_submit:
        R = request.form['pervoe']
        a = request.form['vtoroe']
        b = request.form['tretbe']
        c = request.form['chert']
        answ = (int(a) * int(b) * int(c)) / (int(R) * 4)
        return redirect(f'/answ/{answ}')


@app.route('/Fiz_calc_8', methods=['POST', 'GET'])
def Fiz_calc_8():
    form = Page()
    if request.method == 'GET':
        return render_template('Fiz_calc_8.html', form=form)
    elif request.method == 'POST':
        c = request.form['physical_formulas_8']
        if c == 'The formula for calculating the amount of heat':
            return redirect('/Q')
        elif c == 'The formula for calculating the amount of heat during fuel combustion':
            return redirect('/Q2')
        elif c == 'The formula for calculating the amount of heat required to melt a substance':
            return redirect("/Q3")
        elif c == 'Ohm law for a circuit section':
            return redirect('/Ohm_law')
        elif c == 'Formula for calculating the amount of charge':
            return redirect('/Q4')
        elif c == 'The formula for finding the work of an electric current':
            return  redirect('/A2')
        elif c == 'Electric power formula':
            return redirect('/P3')
        elif c == 'Joule-Lenz law formula':
            return  redirect('/Joule-Lenz')
        elif c == 'The formula for calculating the absolute refractive index of a substance':
            return redirect('N2')


@app.route('/Q', methods=['POST', 'GET'])
def answer18():
    form = Page()
    if request.method == "GET":
        return render_template('Q.html', form=form)
    elif form.validate_on_submit:
        c = request.form['pervoe']
        a = request.form['vtoroe']
        b = request.form['tretbe']
        answ = int(a) * int(b) * int(c)
        return redirect(f'/answ/{answ}')

@app.route('/Q2', methods=['POST', 'GET'])
def answer19():
    form = Page()
    if request.method == "GET":
        return render_template('Q2.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')



@app.route('/Ohm_law', methods=['POST', 'GET'])
def answer20():
    form = Page()
    if request.method == "GET":
        return render_template('Ohm_law.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')



@app.route('/Q3', methods=['POST', 'GET'])
def answer21():
    form = Page()
    if request.method == "GET":
        return render_template('Q3.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/Q4', methods=['POST', 'GET'])
def answer22():
    form = Page()
    if request.method == "GET":
        return render_template('Q4.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/A2', methods=['POST', 'GET'])
def answer23():
    form = Page()
    if request.method == "GET":
        return render_template('A2.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/P3', methods=['POST', 'GET'])
def answer24():
    form = Page()
    if request.method == "GET":
        return render_template('P3.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/Joule-Lenz', methods=['POST', 'GET'])
def answer25():
    form = Page()
    if request.method == "GET":
        return render_template('Joule-Lenz.html', form=form)
    elif form.validate_on_submit:
        c = request.form['pervoe']
        a = request.form['vtoroe']
        b = request.form['tretbe']
        answ = int(b) * (int(a) ** 2) * int(c)
        return redirect(f'/answ/{answ}')


@app.route('/N2', methods=['POST', 'GET'])
def answer26():
    form = Page()
    if request.method == "GET":
        return render_template('N2.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) / int(b)
        return redirect(f'/answ/{answ}')


@app.route('/Fiz_calc_9', methods=['POST', 'GET'])
def Fiz_calc_9():
    form = Page()
    if request.method == 'GET':
        return render_template('Fiz_calc_9.html', form=form)
    elif request.method == 'POST':
        c = request.form['physical_formulas_9']
        if c == 'Formula for calculating the acceleration of a body':
            return redirect('/A3')
        elif c == 'Speed equation':
            return redirect('/V3')
        elif c == 'Newton second law':
            return redirect("/Fn")
        elif c == 'Formula for calculating the height from which a body falls':
            return redirect('/h')
        elif c == 'Formula for calculating centripetal acceleration':
            return redirect('/A4')
        elif c == 'Body momentum formula':
            return  redirect('/p4')
        elif c == 'Formula for calculating power':
            return redirect('/N3')
        elif c == 'Friction force formula':
            return  redirect('/Ftr')
        elif c == 'Mass number':
            return redirect('M2')


@app.route('/A3', methods=['POST', 'GET'])
def answer27():
    form = Page()
    if request.method == "GET":
        return render_template('A3.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        c = request.form['tretbe']
        answ = int(a) - (int(b) * int(c))
        return redirect(f'/answ/{answ}')


@app.route('/V3', methods=['POST', 'GET'])
def answer28():
    form = Page()
    if request.method == "GET":
        return render_template('V3.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        c = request.form['tretbe']
        answ = int(b) + (int(a) * int(c))
        return redirect(f'/answ/{answ}')


@app.route('/Fn', methods=['POST', 'GET'])
def answer29():
    form = Page()
    if request.method == "GET":
        return render_template('Fn.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')

@app.route('/h', methods=['POST', 'GET'])
def answer30():
    form =Page()
    if request.method == "GET":
        return render_template('h.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = (int(a) * (int(b) ** 2)) // 2
        return redirect(f'/answ/{answ}')


@app.route('/A4', methods=['POST', 'GET'])
def answer31():
    form = Page()
    if request.method == "GET":
        return render_template('h.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = (int(b) * (int(a) ** 2)) / 2
        return redirect(f'/answ/{answ}')


@app.route('/Ftr', methods=['POST', 'GET'])
def answer32():
    form = Page()
    if request.method == "GET":
        return render_template('Ftr.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        c = request.form['tretbe']
        answ = int(b) * int(a) * int(c)
        return redirect(f'/answ/{answ}')


@app.route('/p4', methods=['POST', 'GET'])
def answer33():
    form = Page()
    if request.method == "GET":
        return render_template('p4.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) * int(b)
        return redirect(f'/answ/{answ}')


@app.route('/N3', methods=['POST', 'GET'])
def answer34():
    form = Page()
    if request.method == "GET":
        return render_template('N3.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) // int(b)
        return redirect(f'/answ/{answ}')


@app.route('/M2', methods=['POST', 'GET'])
def answer35():
    form = Page()
    if request.method == "GET":
        return render_template('M2.html', form=form)
    elif form.validate_on_submit:
        a = request.form['pervoe']
        b = request.form['vtoroe']
        answ = int(a) + int(b)
        return redirect(f'/answ/{answ}')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)

    #ρ
    #Height_of_a_right triangle
    #Circumference
    #Ohm_law
